/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CreateAnonymousSession
// ====================================================

export interface CreateAnonymousSession_createAnonymousSession_session {
  __typename: "Session";
  id: string;
}

export interface CreateAnonymousSession_createAnonymousSession {
  __typename: "CreatedSession";
  session: CreateAnonymousSession_createAnonymousSession_session;
  rawToken: string;
}

export interface CreateAnonymousSession {
  createAnonymousSession: CreateAnonymousSession_createAnonymousSession;
}

export interface CreateAnonymousSessionVariables {
  fingerprint: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: Login
// ====================================================

export interface Login_login_createdSession_session {
  __typename: "Session";
  id: string;
}

export interface Login_login_createdSession {
  __typename: "CreatedSession";
  session: Login_login_createdSession_session;
  rawToken: string;
}

export interface Login_login {
  __typename: "LoginResponse";
  createdSession: Login_login_createdSession | null;
  error: LoginError | null;
}

export interface Login {
  login: Login_login;
}

export interface LoginVariables {
  emailAddress: string;
  password: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CreatePasswordReset
// ====================================================

export interface CreatePasswordReset_createPasswordReset {
  __typename: "CreatePasswordResetResponse";
  success: boolean;
}

export interface CreatePasswordReset {
  createPasswordReset: CreatePasswordReset_createPasswordReset;
}

export interface CreatePasswordResetVariables {
  emailAddress: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: Signup
// ====================================================

export interface Signup_signup_account {
  __typename: "Account";
  id: string;
}

export interface Signup_signup {
  __typename: "SignupResponse";
  error: SignupError | null;
  account: Signup_signup_account | null;
}

export interface Signup {
  signup: Signup_signup;
}

export interface SignupVariables {
  emailAddress?: string | null;
  password?: string | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: AddToMyColleges
// ====================================================

export interface AddToMyColleges_addToMyColleges_colleges {
  __typename: "College";
  id: string;
}

export interface AddToMyColleges_addToMyColleges {
  __typename: "Student";
  id: string;
  colleges: AddToMyColleges_addToMyColleges_colleges[];
}

export interface AddToMyColleges {
  addToMyColleges: AddToMyColleges_addToMyColleges;
}

export interface AddToMyCollegesVariables {
  studentId: string;
  collegeId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: RemoveFromMyColleges
// ====================================================

export interface RemoveFromMyColleges_removeFromMyColleges_colleges {
  __typename: "College";
  id: string;
}

export interface RemoveFromMyColleges_removeFromMyColleges {
  __typename: "Student";
  id: string;
  colleges: RemoveFromMyColleges_removeFromMyColleges_colleges[];
}

export interface RemoveFromMyColleges {
  removeFromMyColleges: RemoveFromMyColleges_removeFromMyColleges;
}

export interface RemoveFromMyCollegesVariables {
  studentId: string;
  collegeId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: AddToHand
// ====================================================

export interface AddToHand_addToHand_hand_current {
  __typename: "College";
  id: string;
}

export interface AddToHand_addToHand_hand {
  __typename: "Hand";
  current: AddToHand_addToHand_hand_current[];
}

export interface AddToHand_addToHand {
  __typename: "Student";
  id: string;
  hand: AddToHand_addToHand_hand;
}

export interface AddToHand {
  addToHand: AddToHand_addToHand;
}

export interface AddToHandVariables {
  studentId: string;
  collegeId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: RemoveFromHand
// ====================================================

export interface RemoveFromHand_removeFromHand_hand_current {
  __typename: "College";
  id: string;
}

export interface RemoveFromHand_removeFromHand_hand {
  __typename: "Hand";
  current: RemoveFromHand_removeFromHand_hand_current[];
}

export interface RemoveFromHand_removeFromHand {
  __typename: "Student";
  id: string;
  hand: RemoveFromHand_removeFromHand_hand;
}

export interface RemoveFromHand {
  removeFromHand: RemoveFromHand_removeFromHand;
}

export interface RemoveFromHandVariables {
  studentId: string;
  collegeId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CreateInvitation
// ====================================================

export interface CreateInvitation_createInvitation_invitation {
  __typename: "Invitation";
  id: string;
}

export interface CreateInvitation_createInvitation {
  __typename: "CreateInvitationResponse";
  status: InvitationStatus;
  invitation: CreateInvitation_createInvitation_invitation | null;
}

export interface CreateInvitation {
  createInvitation: CreateInvitation_createInvitation;
}

export interface CreateInvitationVariables {
  firstName: string;
  lastName: string;
  emailAddress: string;
  personType: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CompleteInvitation
// ====================================================

export interface CompleteInvitation_completeInvitation {
  __typename: "Invitation";
  id: string;
  permission: InviterPermission | null;
}

export interface CompleteInvitation {
  completeInvitation: CompleteInvitation_completeInvitation;
}

export interface CompleteInvitationVariables {
  invitationId: string;
  inviterPermission: InviterPermission;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CreateSessionFromToken
// ====================================================

export interface CreateSessionFromToken_createSessionFromToken_session {
  __typename: "Session";
  id: string;
}

export interface CreateSessionFromToken_createSessionFromToken {
  __typename: "CreatedSession";
  session: CreateSessionFromToken_createSessionFromToken_session;
  rawToken: string;
}

export interface CreateSessionFromToken {
  createSessionFromToken: CreateSessionFromToken_createSessionFromToken;
}

export interface CreateSessionFromTokenVariables {
  accountToken: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: PurchaseProduct
// ====================================================

export interface PurchaseProduct_submitStripePayment2 {
  __typename: "SubmitStripePaymentResponse";
  status: EStripePaymentStatus;
}

export interface PurchaseProduct {
  submitStripePayment2: PurchaseProduct_submitStripePayment2;
}

export interface PurchaseProductVariables {
  studentId: string;
  stripeToken: string;
  firstName?: string | null;
  lastName?: string | null;
  emailAddress: string;
  productId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CreateReport
// ====================================================

export interface CreateReport_createReport_report {
  __typename: "Report";
  id: string;
}

export interface CreateReport_createReport {
  __typename: "CreatedReport";
  token: string;
  report: CreateReport_createReport_report | null;
}

export interface CreateReport {
  createReport: CreateReport_createReport;
}

export interface CreateReportVariables {
  studentId: string;
  collegeIds: string[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: UpdateProfile
// ====================================================

export interface UpdateProfile_updateProfile {
  __typename: "Account";
  id: string;
}

export interface UpdateProfile {
  updateProfile: UpdateProfile_updateProfile;
}

export interface UpdateProfileVariables {
  data: ProfileUpdateInput;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: InviteParent
// ====================================================

export interface InviteParent_inviteParent {
  __typename: "Account";
  id: string;
}

export interface InviteParent {
  inviteParent: InviteParent_inviteParent;
}

export interface InviteParentVariables {
  emailAddress: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: DismissRecommendation
// ====================================================

export interface DismissRecommendation_dismissRecommendation {
  __typename: "Student";
  id: string;
}

export interface DismissRecommendation {
  dismissRecommendation: DismissRecommendation_dismissRecommendation | null;
}

export interface DismissRecommendationVariables {
  studentId: string;
  collegeId: string;
  reason: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: MarkNotificationsSeen
// ====================================================

export interface MarkNotificationsSeen_markNotificationsSeen_notifications {
  __typename: "Notification";
  id: string;
  lastSeenAt: any | null;
}

export interface MarkNotificationsSeen_markNotificationsSeen {
  __typename: "MarkNotificationsSeenResponse";
  notifications: MarkNotificationsSeen_markNotificationsSeen_notifications[];
}

export interface MarkNotificationsSeen {
  markNotificationsSeen: MarkNotificationsSeen_markNotificationsSeen;
}

export interface MarkNotificationsSeenVariables {
  ids: string[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: UpdateCollegeApplicationStatus
// ====================================================

export interface UpdateCollegeApplicationStatus_updateApplicationStatus_colleges {
  __typename: "College";
  id: string;
  status: CollegeStatus | null;
}

export interface UpdateCollegeApplicationStatus_updateApplicationStatus {
  __typename: "Student";
  id: string;
  colleges: UpdateCollegeApplicationStatus_updateApplicationStatus_colleges[];
}

export interface UpdateCollegeApplicationStatus {
  updateApplicationStatus: UpdateCollegeApplicationStatus_updateApplicationStatus;
}

export interface UpdateCollegeApplicationStatusVariables {
  studentId: string;
  collegeId: string;
  status: CollegeStatus;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: UpdateFinancialAid
// ====================================================

export interface UpdateFinancialAid_updateFinancialAid_colleges {
  __typename: "College";
  id: string;
  financialAidAward: number | null;
}

export interface UpdateFinancialAid_updateFinancialAid {
  __typename: "Student";
  id: string;
  colleges: UpdateFinancialAid_updateFinancialAid_colleges[];
}

export interface UpdateFinancialAid {
  updateFinancialAid: UpdateFinancialAid_updateFinancialAid;
}

export interface UpdateFinancialAidVariables {
  studentId: string;
  collegeId: string;
  input: UpdateFinancialAidInput;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: UpdateFinancialAidAppeal
// ====================================================

export interface UpdateFinancialAidAppeal_updateFinancialAidAppeal_colleges_financialAidAppealLetter {
  __typename: "File";
  id: string;
}

export interface UpdateFinancialAidAppeal_updateFinancialAidAppeal_colleges {
  __typename: "College";
  id: string;
  financialAidAppealAward: number | null;
  financialAidAppealLetter: UpdateFinancialAidAppeal_updateFinancialAidAppeal_colleges_financialAidAppealLetter | null;
}

export interface UpdateFinancialAidAppeal_updateFinancialAidAppeal {
  __typename: "Student";
  id: string;
  colleges: UpdateFinancialAidAppeal_updateFinancialAidAppeal_colleges[];
}

export interface UpdateFinancialAidAppeal {
  updateFinancialAidAppeal: UpdateFinancialAidAppeal_updateFinancialAidAppeal;
}

export interface UpdateFinancialAidAppealVariables {
  studentId: string;
  collegeId: string;
  input: UpdateFinancialAidAppealInput;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: SelectSabrinaBotMessageAction
// ====================================================

export interface SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages_SabrinaBotTextMessage {
  __typename: "SabrinaBotTextMessage";
  id: string;
  createdAt: any;
  text: string;
  actions: string[] | null;
  selectedAction: string | null;
}

export interface SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages_SabrinaBotCTAMessage {
  __typename: "SabrinaBotCTAMessage";
  id: string;
  createdAt: any;
  text: string;
  actions: string[] | null;
  selectedAction: string | null;
  callToActionText: string;
  callToActionUrl: string | null;
}

export type SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages = SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages_SabrinaBotTextMessage | SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages_SabrinaBotCTAMessage;

export interface SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction {
  __typename: "Student";
  id: string;
  sabrinaBotMessages: SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction_sabrinaBotMessages[] | null;
}

export interface SelectSabrinaBotMessageAction {
  selectSabrinaBotMessageAction: SelectSabrinaBotMessageAction_selectSabrinaBotMessageAction;
}

export interface SelectSabrinaBotMessageActionVariables {
  studentId: string;
  messageId: string;
  action: string;
  url: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetMajors
// ====================================================

export interface GetMajors_majors {
  __typename: "Major";
  id: string;
  name: string;
}

export interface GetMajors {
  majors: GetMajors_majors[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetCollegeComparison
// ====================================================

export interface GetCollegeComparison_session_account_person {
  __typename: "Person";
  type: PersonType | null;
}

export interface GetCollegeComparison_session_account {
  __typename: "Account";
  person: GetCollegeComparison_session_account_person | null;
}

export interface GetCollegeComparison_session {
  __typename: "Session";
  account: GetCollegeComparison_session_account;
}

export interface GetCollegeComparison_student_gradePointAverage {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetCollegeComparison_student_normalizedGPA {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_actScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetCollegeComparison_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetCollegeComparison_student_psatScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetCollegeComparison_student_major {
  __typename: "Major";
  id: string;
  name: string;
}

export interface GetCollegeComparison_student_collegeSavingsAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetCollegeComparison_student_person {
  __typename: "Person";
  stage: Stage | null;
}

export interface GetCollegeComparison_student_household_income {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetCollegeComparison_student_household_postalCode {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
}

export interface GetCollegeComparison_student_household {
  __typename: "Household";
  income: GetCollegeComparison_student_household_income;
  postalCode: GetCollegeComparison_student_household_postalCode | null;
}

export interface GetCollegeComparison_student_affordabilityBenchmark {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetCollegeComparison_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetCollegeComparison_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetCollegeComparison_student_appliedProducts_product;
}

export interface GetCollegeComparison_student_reports {
  __typename: "Report";
  id: string;
}

export interface GetCollegeComparison_student_hand_current_logo {
  __typename: "File";
  url: string;
}

export interface GetCollegeComparison_student_hand_current_gpaDifference {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_satScoreDifference {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_majors {
  __typename: "Major";
  id: string;
}

export interface GetCollegeComparison_student_hand_current_averageGPA {
  __typename: "ComputedNullableFloatValue";
  value: number | null;
}

export interface GetCollegeComparison_student_hand_current_averageSATScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetCollegeComparison_student_hand_current_averageACTScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissionUnlikely {
  __typename: "ComputedBooleanValue";
  value: boolean;
}

export interface GetCollegeComparison_student_hand_current_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollegeComparison_student_hand_current_netEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollegeComparison_student_hand_current_debtRemaining {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetCollegeComparison_student_hand_current_edstimate_from = GetCollegeComparison_student_hand_current_edstimate_from_UserNullableIntValue | GetCollegeComparison_student_hand_current_edstimate_from_UserNullableStringValue | GetCollegeComparison_student_hand_current_edstimate_from_UserIntValue | GetCollegeComparison_student_hand_current_edstimate_from_UserNullableFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_UserFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_UserStringValue | GetCollegeComparison_student_hand_current_edstimate_from_UserNullableBooleanValue | GetCollegeComparison_student_hand_current_edstimate_from_UserBooleanValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableIntValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemIntValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableStringValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemStringValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemNullableBooleanValue | GetCollegeComparison_student_hand_current_edstimate_from_SystemBooleanValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableIntValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableFloatValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedIntValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedBooleanValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableStringValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedStringValue | GetCollegeComparison_student_hand_current_edstimate_from_ComputedNullableBooleanValue;

export interface GetCollegeComparison_student_hand_current_edstimate {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetCollegeComparison_student_hand_current_edstimate_from[];
  value: number;
}

export interface GetCollegeComparison_student_hand_current_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetCollegeComparison_student_hand_current_admissibility_from = GetCollegeComparison_student_hand_current_admissibility_from_UserNullableIntValue | GetCollegeComparison_student_hand_current_admissibility_from_UserNullableStringValue | GetCollegeComparison_student_hand_current_admissibility_from_UserIntValue | GetCollegeComparison_student_hand_current_admissibility_from_UserNullableFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_UserFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_UserStringValue | GetCollegeComparison_student_hand_current_admissibility_from_UserNullableBooleanValue | GetCollegeComparison_student_hand_current_admissibility_from_UserBooleanValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableIntValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemIntValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableStringValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemStringValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemNullableBooleanValue | GetCollegeComparison_student_hand_current_admissibility_from_SystemBooleanValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableIntValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableFloatValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedIntValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedBooleanValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableStringValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedStringValue | GetCollegeComparison_student_hand_current_admissibility_from_ComputedNullableBooleanValue;

export interface GetCollegeComparison_student_hand_current_admissibility {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetCollegeComparison_student_hand_current_admissibility_from[];
  value: number;
}

export interface GetCollegeComparison_student_hand_current_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetCollegeComparison_student_hand_current_costOfAttendance_from = GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserNullableBooleanValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_UserBooleanValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemNullableBooleanValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_SystemBooleanValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableFloatValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedIntValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedBooleanValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedStringValue | GetCollegeComparison_student_hand_current_costOfAttendance_from_ComputedNullableBooleanValue;

export interface GetCollegeComparison_student_hand_current_costOfAttendance {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetCollegeComparison_student_hand_current_costOfAttendance_from[];
  value: number;
}

export interface GetCollegeComparison_student_hand_current {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetCollegeComparison_student_hand_current_logo | null;
  scholarships: string[];
  gpaDifference: GetCollegeComparison_student_hand_current_gpaDifference;
  satScoreDifference: GetCollegeComparison_student_hand_current_satScoreDifference;
  majors: GetCollegeComparison_student_hand_current_majors[];
  averageGPA: GetCollegeComparison_student_hand_current_averageGPA;
  averageSATScore: GetCollegeComparison_student_hand_current_averageSATScore;
  averageACTScore: GetCollegeComparison_student_hand_current_averageACTScore;
  averageHHI: number;
  publishedTuition: number;
  admissionUnlikely: GetCollegeComparison_student_hand_current_admissionUnlikely;
  accumulatedEarnings: GetCollegeComparison_student_hand_current_accumulatedEarnings;
  /**
   * from 0 to 1
   */
  medianEarnings: GetCollegeComparison_student_hand_current_medianEarnings[];
  netEarnings: GetCollegeComparison_student_hand_current_netEarnings[];
  debtRemaining: GetCollegeComparison_student_hand_current_debtRemaining[];
  repaymentRate: number;
  edstimate: GetCollegeComparison_student_hand_current_edstimate;
  fitScore: GetCollegeComparison_student_hand_current_fitScore;
  admissibility: GetCollegeComparison_student_hand_current_admissibility;
  affordabilityScore: GetCollegeComparison_student_hand_current_affordabilityScore;
  valueScore: GetCollegeComparison_student_hand_current_valueScore;
  earningsScore: GetCollegeComparison_student_hand_current_earningsScore;
  costOfAttendance: GetCollegeComparison_student_hand_current_costOfAttendance;
  financialAidAward: number | null;
}

export interface GetCollegeComparison_student_hand_recent_logo {
  __typename: "File";
  url: string;
}

export interface GetCollegeComparison_student_hand_recent_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_recent_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_recent_admissibility {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_recent_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetCollegeComparison_student_hand_recent {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetCollegeComparison_student_hand_recent_logo | null;
  edstimate: GetCollegeComparison_student_hand_recent_edstimate;
  fitScore: GetCollegeComparison_student_hand_recent_fitScore;
  admissibility: GetCollegeComparison_student_hand_recent_admissibility;
  costOfAttendance: GetCollegeComparison_student_hand_recent_costOfAttendance;
}

export interface GetCollegeComparison_student_hand {
  __typename: "Hand";
  current: GetCollegeComparison_student_hand_current[];
  recent: GetCollegeComparison_student_hand_recent[];
}

export interface GetCollegeComparison_student {
  __typename: "Student";
  id: string;
  gradePointAverage: GetCollegeComparison_student_gradePointAverage;
  normalizedGPA: GetCollegeComparison_student_normalizedGPA;
  actScore: GetCollegeComparison_student_actScore;
  satScore: GetCollegeComparison_student_satScore;
  psatScore: GetCollegeComparison_student_psatScore;
  major: GetCollegeComparison_student_major | null;
  collegeSavingsAmount: GetCollegeComparison_student_collegeSavingsAmount;
  person: GetCollegeComparison_student_person | null;
  household: GetCollegeComparison_student_household | null;
  affordabilityBenchmark: GetCollegeComparison_student_affordabilityBenchmark;
  appliedProducts: GetCollegeComparison_student_appliedProducts[];
  reports: GetCollegeComparison_student_reports[];
  hand: GetCollegeComparison_student_hand;
}

export interface GetCollegeComparison {
  session: GetCollegeComparison_session | null;
  student: GetCollegeComparison_student;
}

export interface GetCollegeComparisonVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetComparisonColleges
// ====================================================

export interface GetComparisonColleges_student_hand_current_logo {
  __typename: "File";
  url: string;
}

export interface GetComparisonColleges_student_hand_current {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetComparisonColleges_student_hand_current_logo | null;
}

export interface GetComparisonColleges_student_hand_recent_logo {
  __typename: "File";
  url: string;
}

export interface GetComparisonColleges_student_hand_recent {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetComparisonColleges_student_hand_recent_logo | null;
}

export interface GetComparisonColleges_student_hand {
  __typename: "Hand";
  current: GetComparisonColleges_student_hand_current[];
  recent: GetComparisonColleges_student_hand_recent[];
}

export interface GetComparisonColleges_student {
  __typename: "Student";
  id: string;
  hand: GetComparisonColleges_student_hand;
}

export interface GetComparisonColleges {
  student: GetComparisonColleges_student;
}

export interface GetComparisonCollegesVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetReport
// ====================================================

export interface GetReport_report_student_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface GetReport_report_student_gradePointAverage {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetReport_report_student_normalizedGPA {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_student_actScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetReport_report_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetReport_report_student_psatScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetReport_report_student_major {
  __typename: "Major";
  id: string;
  name: string;
}

export interface GetReport_report_student_collegeSavingsAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetReport_report_student_cashContributionAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetReport_report_student_workStudyAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetReport_report_student_household_income {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetReport_report_student_household_postalCode {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
}

export interface GetReport_report_student_household {
  __typename: "Household";
  income: GetReport_report_student_household_income;
  postalCode: GetReport_report_student_household_postalCode | null;
}

export interface GetReport_report_student_affordabilityBenchmark {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetReport_report_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetReport_report_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetReport_report_student_appliedProducts_product;
}

export interface GetReport_report_student {
  __typename: "Student";
  id: string;
  person: GetReport_report_student_person | null;
  gradePointAverage: GetReport_report_student_gradePointAverage;
  normalizedGPA: GetReport_report_student_normalizedGPA;
  actScore: GetReport_report_student_actScore;
  satScore: GetReport_report_student_satScore;
  psatScore: GetReport_report_student_psatScore;
  major: GetReport_report_student_major | null;
  collegeSavingsAmount: GetReport_report_student_collegeSavingsAmount;
  cashContributionAmount: GetReport_report_student_cashContributionAmount;
  workStudyAmount: GetReport_report_student_workStudyAmount;
  household: GetReport_report_student_household | null;
  affordabilityBenchmark: GetReport_report_student_affordabilityBenchmark;
  appliedProducts: GetReport_report_student_appliedProducts[];
}

export interface GetReport_report_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetReport_report_colleges_gpaDifference {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_satScoreDifference {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_averageGPA {
  __typename: "ComputedNullableFloatValue";
  value: number | null;
}

export interface GetReport_report_colleges_averageSATScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetReport_report_colleges_averageACTScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetReport_report_colleges_admissionUnlikely {
  __typename: "ComputedBooleanValue";
  value: boolean;
}

export interface GetReport_report_colleges_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetReport_report_colleges_netEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetReport_report_colleges_debtRemaining {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetReport_report_colleges_edstimate_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_edstimate_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_edstimate_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_edstimate_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_edstimate_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_edstimate_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_edstimate_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_edstimate_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_edstimate_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_edstimate_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_edstimate_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_edstimate_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_edstimate_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetReport_report_colleges_edstimate_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_edstimate_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetReport_report_colleges_edstimate_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_edstimate_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_edstimate_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetReport_report_colleges_edstimate_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetReport_report_colleges_edstimate_from = GetReport_report_colleges_edstimate_from_UserNullableIntValue | GetReport_report_colleges_edstimate_from_UserNullableStringValue | GetReport_report_colleges_edstimate_from_UserIntValue | GetReport_report_colleges_edstimate_from_UserNullableFloatValue | GetReport_report_colleges_edstimate_from_UserFloatValue | GetReport_report_colleges_edstimate_from_UserStringValue | GetReport_report_colleges_edstimate_from_UserNullableBooleanValue | GetReport_report_colleges_edstimate_from_UserBooleanValue | GetReport_report_colleges_edstimate_from_SystemNullableIntValue | GetReport_report_colleges_edstimate_from_SystemIntValue | GetReport_report_colleges_edstimate_from_SystemNullableFloatValue | GetReport_report_colleges_edstimate_from_SystemFloatValue | GetReport_report_colleges_edstimate_from_SystemNullableStringValue | GetReport_report_colleges_edstimate_from_SystemStringValue | GetReport_report_colleges_edstimate_from_SystemNullableBooleanValue | GetReport_report_colleges_edstimate_from_SystemBooleanValue | GetReport_report_colleges_edstimate_from_ComputedFloatValue | GetReport_report_colleges_edstimate_from_ComputedNullableIntValue | GetReport_report_colleges_edstimate_from_ComputedNullableFloatValue | GetReport_report_colleges_edstimate_from_ComputedIntValue | GetReport_report_colleges_edstimate_from_ComputedBooleanValue | GetReport_report_colleges_edstimate_from_ComputedNullableStringValue | GetReport_report_colleges_edstimate_from_ComputedStringValue | GetReport_report_colleges_edstimate_from_ComputedNullableBooleanValue;

export interface GetReport_report_colleges_edstimate {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetReport_report_colleges_edstimate_from[];
  value: number;
}

export interface GetReport_report_colleges_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetReport_report_colleges_admissibility_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_admissibility_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_admissibility_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_admissibility_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_admissibility_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_admissibility_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_admissibility_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_admissibility_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_admissibility_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_admissibility_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_admissibility_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_admissibility_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_admissibility_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetReport_report_colleges_admissibility_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_admissibility_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetReport_report_colleges_admissibility_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_admissibility_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_admissibility_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetReport_report_colleges_admissibility_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetReport_report_colleges_admissibility_from = GetReport_report_colleges_admissibility_from_UserNullableIntValue | GetReport_report_colleges_admissibility_from_UserNullableStringValue | GetReport_report_colleges_admissibility_from_UserIntValue | GetReport_report_colleges_admissibility_from_UserNullableFloatValue | GetReport_report_colleges_admissibility_from_UserFloatValue | GetReport_report_colleges_admissibility_from_UserStringValue | GetReport_report_colleges_admissibility_from_UserNullableBooleanValue | GetReport_report_colleges_admissibility_from_UserBooleanValue | GetReport_report_colleges_admissibility_from_SystemNullableIntValue | GetReport_report_colleges_admissibility_from_SystemIntValue | GetReport_report_colleges_admissibility_from_SystemNullableFloatValue | GetReport_report_colleges_admissibility_from_SystemFloatValue | GetReport_report_colleges_admissibility_from_SystemNullableStringValue | GetReport_report_colleges_admissibility_from_SystemStringValue | GetReport_report_colleges_admissibility_from_SystemNullableBooleanValue | GetReport_report_colleges_admissibility_from_SystemBooleanValue | GetReport_report_colleges_admissibility_from_ComputedFloatValue | GetReport_report_colleges_admissibility_from_ComputedNullableIntValue | GetReport_report_colleges_admissibility_from_ComputedNullableFloatValue | GetReport_report_colleges_admissibility_from_ComputedIntValue | GetReport_report_colleges_admissibility_from_ComputedBooleanValue | GetReport_report_colleges_admissibility_from_ComputedNullableStringValue | GetReport_report_colleges_admissibility_from_ComputedStringValue | GetReport_report_colleges_admissibility_from_ComputedNullableBooleanValue;

export interface GetReport_report_colleges_admissibility {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetReport_report_colleges_admissibility_from[];
  value: number;
}

export interface GetReport_report_colleges_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetReport_report_colleges_costOfAttendance_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetReport_report_colleges_costOfAttendance_from = GetReport_report_colleges_costOfAttendance_from_UserNullableIntValue | GetReport_report_colleges_costOfAttendance_from_UserNullableStringValue | GetReport_report_colleges_costOfAttendance_from_UserIntValue | GetReport_report_colleges_costOfAttendance_from_UserNullableFloatValue | GetReport_report_colleges_costOfAttendance_from_UserFloatValue | GetReport_report_colleges_costOfAttendance_from_UserStringValue | GetReport_report_colleges_costOfAttendance_from_UserNullableBooleanValue | GetReport_report_colleges_costOfAttendance_from_UserBooleanValue | GetReport_report_colleges_costOfAttendance_from_SystemNullableIntValue | GetReport_report_colleges_costOfAttendance_from_SystemIntValue | GetReport_report_colleges_costOfAttendance_from_SystemNullableFloatValue | GetReport_report_colleges_costOfAttendance_from_SystemFloatValue | GetReport_report_colleges_costOfAttendance_from_SystemNullableStringValue | GetReport_report_colleges_costOfAttendance_from_SystemStringValue | GetReport_report_colleges_costOfAttendance_from_SystemNullableBooleanValue | GetReport_report_colleges_costOfAttendance_from_SystemBooleanValue | GetReport_report_colleges_costOfAttendance_from_ComputedFloatValue | GetReport_report_colleges_costOfAttendance_from_ComputedNullableIntValue | GetReport_report_colleges_costOfAttendance_from_ComputedNullableFloatValue | GetReport_report_colleges_costOfAttendance_from_ComputedIntValue | GetReport_report_colleges_costOfAttendance_from_ComputedBooleanValue | GetReport_report_colleges_costOfAttendance_from_ComputedNullableStringValue | GetReport_report_colleges_costOfAttendance_from_ComputedStringValue | GetReport_report_colleges_costOfAttendance_from_ComputedNullableBooleanValue;

export interface GetReport_report_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetReport_report_colleges_costOfAttendance_from[];
  value: number;
}

export interface GetReport_report_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetReport_report_colleges_logo | null;
  gpaDifference: GetReport_report_colleges_gpaDifference;
  satScoreDifference: GetReport_report_colleges_satScoreDifference;
  averageGPA: GetReport_report_colleges_averageGPA;
  averageSATScore: GetReport_report_colleges_averageSATScore;
  averageACTScore: GetReport_report_colleges_averageACTScore;
  publishedTuition: number;
  admissionUnlikely: GetReport_report_colleges_admissionUnlikely;
  accumulatedEarnings: GetReport_report_colleges_accumulatedEarnings;
  /**
   * from 0 to 1
   */
  medianEarnings: GetReport_report_colleges_medianEarnings[];
  netEarnings: GetReport_report_colleges_netEarnings[];
  debtRemaining: GetReport_report_colleges_debtRemaining[];
  repaymentRate: number;
  edstimate: GetReport_report_colleges_edstimate;
  fitScore: GetReport_report_colleges_fitScore;
  admissibility: GetReport_report_colleges_admissibility;
  affordabilityScore: GetReport_report_colleges_affordabilityScore;
  valueScore: GetReport_report_colleges_valueScore;
  earningsScore: GetReport_report_colleges_earningsScore;
  costOfAttendance: GetReport_report_colleges_costOfAttendance;
  financialAidAward: number | null;
}

export interface GetReport_report {
  __typename: "Report";
  student: GetReport_report_student;
  colleges: GetReport_report_colleges[];
}

export interface GetReport {
  report: GetReport_report;
}

export interface GetReportVariables {
  token: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetOnboardingStudent
// ====================================================

export interface GetOnboardingStudent_student_highSchoolGraduationYear {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetOnboardingStudent_student_gradePointAverage {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetOnboardingStudent_student_actScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetOnboardingStudent_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetOnboardingStudent_student_psatScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetOnboardingStudent_student_major {
  __typename: "Major";
  id: string;
  name: string;
}

export interface GetOnboardingStudent_student_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  stage: Stage | null;
  type: PersonType | null;
}

export interface GetOnboardingStudent_student_household_postalCode_city_state {
  __typename: "State";
  abbreviation: string;
}

export interface GetOnboardingStudent_student_household_postalCode_city {
  __typename: "City";
  name: string;
  state: GetOnboardingStudent_student_household_postalCode_city_state;
}

export interface GetOnboardingStudent_student_household_postalCode {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
  city: GetOnboardingStudent_student_household_postalCode_city;
}

export interface GetOnboardingStudent_student_household {
  __typename: "Household";
  postalCode: GetOnboardingStudent_student_household_postalCode | null;
}

export interface GetOnboardingStudent_student {
  __typename: "Student";
  id: string;
  highSchoolGraduationYear: GetOnboardingStudent_student_highSchoolGraduationYear;
  gradePointAverage: GetOnboardingStudent_student_gradePointAverage;
  actScore: GetOnboardingStudent_student_actScore;
  satScore: GetOnboardingStudent_student_satScore;
  psatScore: GetOnboardingStudent_student_psatScore;
  major: GetOnboardingStudent_student_major | null;
  person: GetOnboardingStudent_student_person | null;
  household: GetOnboardingStudent_student_household | null;
}

export interface GetOnboardingStudent {
  student: GetOnboardingStudent_student;
}

export interface GetOnboardingStudentVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetOnboardingCollege
// ====================================================

export interface GetOnboardingCollege_college_logo {
  __typename: "File";
  url: string;
}

export interface GetOnboardingCollege_college_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetOnboardingCollege_college_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetOnboardingCollege_college_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetOnboardingCollege_college_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetOnboardingCollege_college_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetOnboardingCollege_college {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetOnboardingCollege_college_logo | null;
  affordabilityScore: GetOnboardingCollege_college_affordabilityScore;
  valueScore: GetOnboardingCollege_college_valueScore;
  earningsScore: GetOnboardingCollege_college_earningsScore;
  fitScore: GetOnboardingCollege_college_fitScore;
  edstimate: GetOnboardingCollege_college_edstimate;
}

export interface GetOnboardingCollege {
  college: GetOnboardingCollege_college;
}

export interface GetOnboardingCollegeVariables {
  studentId: string;
  collegeId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetInboundInvitations
// ====================================================

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode_city_state;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode {
  __typename: "PostalCode";
  city: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode_city;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_admissionUnlikely {
  __typename: "ComputedBooleanValue";
  value: boolean;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_admissibility {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_firstYearEarnings {
  __typename: "EarningsDataPoint";
  value: number;
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_logo | null;
  postalCode: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_postalCode;
  publishedTuition: number;
  admissionUnlikely: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_admissionUnlikely;
  costOfAttendance: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_costOfAttendance;
  edstimate: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_edstimate;
  fitScore: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_fitScore;
  affordabilityScore: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_affordabilityScore;
  valueScore: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_valueScore;
  earningsScore: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_earningsScore;
  admissibility: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_admissibility;
  /**
   * from 0 to 1
   */
  firstYearEarnings: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges_firstYearEarnings[];
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter_student {
  __typename: "Student";
  colleges: GetInboundInvitations_session_account_inboundInvitations_inviter_student_colleges[];
}

export interface GetInboundInvitations_session_account_inboundInvitations_inviter {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  student: GetInboundInvitations_session_account_inboundInvitations_inviter_student | null;
}

export interface GetInboundInvitations_session_account_inboundInvitations {
  __typename: "Invitation";
  id: string;
  inviter: GetInboundInvitations_session_account_inboundInvitations_inviter;
}

export interface GetInboundInvitations_session_account {
  __typename: "Account";
  inboundInvitations: GetInboundInvitations_session_account_inboundInvitations[];
}

export interface GetInboundInvitations_session {
  __typename: "Session";
  account: GetInboundInvitations_session_account;
}

export interface GetInboundInvitations {
  session: GetInboundInvitations_session | null;
}

export interface GetInboundInvitationsVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetMyColleges
// ====================================================

export interface GetMyColleges_student_person {
  __typename: "Person";
  type: PersonType | null;
  affinities: Affinity[] | null;
  stage: Stage | null;
}

export interface GetMyColleges_student_major {
  __typename: "Major";
  id: string;
}

export interface GetMyColleges_student_hand_current {
  __typename: "College";
  id: string;
}

export interface GetMyColleges_student_hand {
  __typename: "Hand";
  current: GetMyColleges_student_hand_current[];
}

export interface GetMyColleges_student_affordabilityBenchmark {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetMyColleges_student_normalizedGPA {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetMyColleges_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetMyColleges_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetMyColleges_student_appliedProducts_product;
}

export interface GetMyColleges_student_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetMyColleges_student_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetMyColleges_student_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: GetMyColleges_student_colleges_postalCode_city_state;
}

export interface GetMyColleges_student_colleges_postalCode {
  __typename: "PostalCode";
  city: GetMyColleges_student_colleges_postalCode_city;
}

export interface GetMyColleges_student_colleges_majors {
  __typename: "Major";
  id: string;
}

export interface GetMyColleges_student_colleges_admissionUnlikely {
  __typename: "ComputedBooleanValue";
  value: boolean;
}

export interface GetMyColleges_student_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetMyColleges_student_colleges_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_admissibility {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMyColleges_student_colleges_debtRemaining {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetMyColleges_student_colleges_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetMyColleges_student_colleges_averageGPA {
  __typename: "ComputedNullableFloatValue";
  value: number | null;
}

export interface GetMyColleges_student_colleges_averageSATScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetMyColleges_student_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetMyColleges_student_colleges_logo | null;
  postalCode: GetMyColleges_student_colleges_postalCode;
  publishedTuition: number;
  majors: GetMyColleges_student_colleges_majors[];
  admissionUnlikely: GetMyColleges_student_colleges_admissionUnlikely;
  costOfAttendance: GetMyColleges_student_colleges_costOfAttendance;
  edstimate: GetMyColleges_student_colleges_edstimate;
  scholarships: string[];
  fitScore: GetMyColleges_student_colleges_fitScore;
  affordabilityScore: GetMyColleges_student_colleges_affordabilityScore;
  valueScore: GetMyColleges_student_colleges_valueScore;
  earningsScore: GetMyColleges_student_colleges_earningsScore;
  admissibility: GetMyColleges_student_colleges_admissibility;
  accumulatedEarnings: GetMyColleges_student_colleges_accumulatedEarnings;
  debtRemaining: GetMyColleges_student_colleges_debtRemaining[];
  /**
   * from 0 to 1
   */
  medianEarnings: GetMyColleges_student_colleges_medianEarnings[];
  financialAidAward: number | null;
  status: CollegeStatus | null;
  averageGPA: GetMyColleges_student_colleges_averageGPA;
  averageSATScore: GetMyColleges_student_colleges_averageSATScore;
}

export interface GetMyColleges_student {
  __typename: "Student";
  id: string;
  person: GetMyColleges_student_person | null;
  major: GetMyColleges_student_major | null;
  hand: GetMyColleges_student_hand;
  affordabilityBenchmark: GetMyColleges_student_affordabilityBenchmark;
  normalizedGPA: GetMyColleges_student_normalizedGPA;
  satScore: GetMyColleges_student_satScore;
  appliedProducts: GetMyColleges_student_appliedProducts[];
  colleges: GetMyColleges_student_colleges[];
}

export interface GetMyColleges {
  student: GetMyColleges_student;
}

export interface GetMyCollegesVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SearchColleges
// ====================================================

export interface SearchColleges_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface SearchColleges_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: SearchColleges_colleges_postalCode_city_state;
}

export interface SearchColleges_colleges_postalCode {
  __typename: "PostalCode";
  city: SearchColleges_colleges_postalCode_city;
}

export interface SearchColleges_colleges {
  __typename: "College";
  id: string;
  name: string;
  postalCode: SearchColleges_colleges_postalCode;
}

export interface SearchColleges {
  colleges: SearchColleges_colleges[];
}

export interface SearchCollegesVariables {
  searchString: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SearchMyColleges
// ====================================================

export interface SearchMyColleges_student_colleges_logo {
  __typename: "File";
  url: string;
}

export interface SearchMyColleges_student_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface SearchMyColleges_student_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: SearchMyColleges_student_colleges_postalCode_city_state;
}

export interface SearchMyColleges_student_colleges_postalCode {
  __typename: "PostalCode";
  city: SearchMyColleges_student_colleges_postalCode_city;
}

export interface SearchMyColleges_student_colleges_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface SearchMyColleges_student_colleges {
  __typename: "College";
  id: string;
  name: string;
  logo: SearchMyColleges_student_colleges_logo | null;
  postalCode: SearchMyColleges_student_colleges_postalCode;
  fitScore: SearchMyColleges_student_colleges_fitScore;
}

export interface SearchMyColleges_student {
  __typename: "Student";
  colleges: SearchMyColleges_student_colleges[];
}

export interface SearchMyColleges {
  student: SearchMyColleges_student;
}

export interface SearchMyCollegesVariables {
  searchString: string;
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SearchHighSchools
// ====================================================

export interface SearchHighSchools_highSchools_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface SearchHighSchools_highSchools_postalCode_city {
  __typename: "City";
  name: string;
  state: SearchHighSchools_highSchools_postalCode_city_state;
}

export interface SearchHighSchools_highSchools_postalCode {
  __typename: "PostalCode";
  city: SearchHighSchools_highSchools_postalCode_city;
  postalCode: string;
}

export interface SearchHighSchools_highSchools {
  __typename: "HighSchool";
  id: string;
  name: string;
  postalCode: SearchHighSchools_highSchools_postalCode;
}

export interface SearchHighSchools {
  highSchools: SearchHighSchools_highSchools[];
}

export interface SearchHighSchoolsVariables {
  searchString: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SearchPostalCodes
// ====================================================

export interface SearchPostalCodes_postalCodes_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface SearchPostalCodes_postalCodes_city {
  __typename: "City";
  name: string;
  state: SearchPostalCodes_postalCodes_city_state;
}

export interface SearchPostalCodes_postalCodes {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
  city: SearchPostalCodes_postalCodes_city;
}

export interface SearchPostalCodes {
  postalCodes: SearchPostalCodes_postalCodes[];
}

export interface SearchPostalCodesVariables {
  searchString: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SearchStudents
// ====================================================

export interface SearchStudents_students_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface SearchStudents_students {
  __typename: "Student";
  id: string;
  person: SearchStudents_students_person | null;
}

export interface SearchStudents {
  students: SearchStudents_students[];
}

export interface SearchStudentsVariables {
  searchString: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ValidateSession
// ====================================================

export interface ValidateSession_session_account_emailAddress {
  __typename: "EmailAddress";
  emailAddress: string;
}

export interface ValidateSession_session_account_person {
  __typename: "Person";
  id: string;
  firstName: string | null;
  lastName: string | null;
}

export interface ValidateSession_session_account {
  __typename: "Account";
  id: string;
  emailAddress: ValidateSession_session_account_emailAddress | null;
  person: ValidateSession_session_account_person | null;
}

export interface ValidateSession_session {
  __typename: "Session";
  id: string;
  account: ValidateSession_session_account;
}

export interface ValidateSession {
  session: ValidateSession_session | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetSession
// ====================================================

export interface GetSession_session_account_emailAddress {
  __typename: "EmailAddress";
  id: string;
}

export interface GetSession_session_account_outboundInvitations {
  __typename: "Invitation";
  id: string;
  permission: InviterPermission | null;
}

export interface GetSession_session_account_notifications {
  __typename: "Notification";
  id: string;
  title: string;
  message: string | null;
  effectiveAt: any;
  link: string | null;
  lastSeenAt: any | null;
}

export interface GetSession_session_account_person_parent_children_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface GetSession_session_account_person_parent_children {
  __typename: "Student";
  id: string;
  person: GetSession_session_account_person_parent_children_person | null;
}

export interface GetSession_session_account_person_parent {
  __typename: "Parent";
  id: string;
  children: GetSession_session_account_person_parent_children[];
}

export interface GetSession_session_account_person_counselor_students_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface GetSession_session_account_person_counselor_students {
  __typename: "Student";
  id: string;
  person: GetSession_session_account_person_counselor_students_person | null;
}

export interface GetSession_session_account_person_counselor {
  __typename: "Counselor";
  id: string;
  students: GetSession_session_account_person_counselor_students[];
}

export interface GetSession_session_account_person_student_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface GetSession_session_account_person_student {
  __typename: "Student";
  id: string;
  person: GetSession_session_account_person_student_person | null;
}

export interface GetSession_session_account_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  stage: Stage | null;
  affinities: Affinity[] | null;
  parent: GetSession_session_account_person_parent | null;
  counselor: GetSession_session_account_person_counselor | null;
  student: GetSession_session_account_person_student | null;
}

export interface GetSession_session_account {
  __typename: "Account";
  emailAddress: GetSession_session_account_emailAddress | null;
  hasPassword: boolean;
  outboundInvitations: GetSession_session_account_outboundInvitations[];
  notifications: GetSession_session_account_notifications[];
  isSuperUser: boolean;
  person: GetSession_session_account_person | null;
}

export interface GetSession_session {
  __typename: "Session";
  expiresAt: any;
  account: GetSession_session_account;
}

export interface GetSession {
  session: GetSession_session | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetCurrentStudent
// ====================================================

export interface GetCurrentStudent_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetCurrentStudent_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetCurrentStudent_student_appliedProducts_product;
}

export interface GetCurrentStudent_student {
  __typename: "Student";
  id: string;
  appliedProducts: GetCurrentStudent_student_appliedProducts[];
}

export interface GetCurrentStudent {
  student: GetCurrentStudent_student;
}

export interface GetCurrentStudentVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetCollege
// ====================================================

export interface GetCollege_college_logo {
  __typename: "File";
  url: string;
}

export interface GetCollege_college_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
  slug: string | null;
}

export interface GetCollege_college_postalCode_city {
  __typename: "City";
  name: string;
  state: GetCollege_college_postalCode_city_state;
}

export interface GetCollege_college_postalCode {
  __typename: "PostalCode";
  city: GetCollege_college_postalCode_city;
}

export interface GetCollege_college_costOfAttendance_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollege_college_costOfAttendance_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetCollege_college_costOfAttendance_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollege_college_costOfAttendance_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollege_college_costOfAttendance_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollege_college_costOfAttendance_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollege_college_costOfAttendance_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetCollege_college_costOfAttendance_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetCollege_college_costOfAttendance_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetCollege_college_costOfAttendance_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetCollege_college_costOfAttendance_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetCollege_college_costOfAttendance_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetCollege_college_costOfAttendance_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetCollege_college_costOfAttendance_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetCollege_college_costOfAttendance_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetCollege_college_costOfAttendance_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetCollege_college_costOfAttendance_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetCollege_college_costOfAttendance_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetCollege_college_costOfAttendance_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetCollege_college_costOfAttendance_from = GetCollege_college_costOfAttendance_from_UserNullableIntValue | GetCollege_college_costOfAttendance_from_UserNullableStringValue | GetCollege_college_costOfAttendance_from_UserIntValue | GetCollege_college_costOfAttendance_from_UserNullableFloatValue | GetCollege_college_costOfAttendance_from_UserFloatValue | GetCollege_college_costOfAttendance_from_UserStringValue | GetCollege_college_costOfAttendance_from_UserNullableBooleanValue | GetCollege_college_costOfAttendance_from_UserBooleanValue | GetCollege_college_costOfAttendance_from_SystemNullableIntValue | GetCollege_college_costOfAttendance_from_SystemIntValue | GetCollege_college_costOfAttendance_from_SystemNullableFloatValue | GetCollege_college_costOfAttendance_from_SystemFloatValue | GetCollege_college_costOfAttendance_from_SystemNullableStringValue | GetCollege_college_costOfAttendance_from_SystemStringValue | GetCollege_college_costOfAttendance_from_SystemNullableBooleanValue | GetCollege_college_costOfAttendance_from_SystemBooleanValue | GetCollege_college_costOfAttendance_from_ComputedFloatValue | GetCollege_college_costOfAttendance_from_ComputedNullableIntValue | GetCollege_college_costOfAttendance_from_ComputedNullableFloatValue | GetCollege_college_costOfAttendance_from_ComputedIntValue | GetCollege_college_costOfAttendance_from_ComputedBooleanValue | GetCollege_college_costOfAttendance_from_ComputedNullableStringValue | GetCollege_college_costOfAttendance_from_ComputedStringValue | GetCollege_college_costOfAttendance_from_ComputedNullableBooleanValue;

export interface GetCollege_college_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: GetCollege_college_costOfAttendance_from[];
}

export interface GetCollege_college_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollege_college_netEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollege_college_debtRemaining {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetCollege_college {
  __typename: "College";
  id: string;
  name: string;
  url: string | null;
  logo: GetCollege_college_logo | null;
  type: CollegeType;
  abbreviation: string;
  postalCode: GetCollege_college_postalCode;
  costOfAttendance: GetCollege_college_costOfAttendance;
  /**
   * from 0 to 1
   */
  medianEarnings: GetCollege_college_medianEarnings[];
  netEarnings: GetCollege_college_netEarnings[];
  debtRemaining: GetCollege_college_debtRemaining[];
  repaymentRate: number;
  meetFinancialAid: number | null;
  /**
   * from 0 to 1
   */
  averageMeritScholarship: number | null;
  averagePrice: number | null;
  publishedTuition: number;
}

export interface GetCollege {
  college: GetCollege_college;
}

export interface GetCollegeVariables {
  collegeSlug: string;
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetFinancialPlanner
// ====================================================

export interface GetFinancialPlanner_session_account_person {
  __typename: "Person";
  type: PersonType | null;
}

export interface GetFinancialPlanner_session_account {
  __typename: "Account";
  person: GetFinancialPlanner_session_account_person | null;
}

export interface GetFinancialPlanner_session {
  __typename: "Session";
  account: GetFinancialPlanner_session_account;
}

export interface GetFinancialPlanner_student_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  stage: Stage | null;
}

export interface GetFinancialPlanner_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetFinancialPlanner_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetFinancialPlanner_student_appliedProducts_product;
}

export interface GetFinancialPlanner_student_workStudyAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetFinancialPlanner_student_cashContributionAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetFinancialPlanner_student_collegeSavingsAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetFinancialPlanner_student_topChoice_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetFinancialPlanner_student_topChoice_postalCode_city {
  __typename: "City";
  name: string;
  state: GetFinancialPlanner_student_topChoice_postalCode_city_state;
}

export interface GetFinancialPlanner_student_topChoice_postalCode {
  __typename: "PostalCode";
  city: GetFinancialPlanner_student_topChoice_postalCode_city;
}

export interface GetFinancialPlanner_student_topChoice_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetFinancialPlanner_student_topChoice_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetFinancialPlanner_student_topChoice_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetFinancialPlanner_student_topChoice {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  postalCode: GetFinancialPlanner_student_topChoice_postalCode;
  financialAidAward: number | null;
  costOfAttendance: GetFinancialPlanner_student_topChoice_costOfAttendance;
  edstimate: GetFinancialPlanner_student_topChoice_edstimate;
  /**
   * from 0 to 1
   */
  medianEarnings: GetFinancialPlanner_student_topChoice_medianEarnings[];
}

export interface GetFinancialPlanner_student {
  __typename: "Student";
  id: string;
  person: GetFinancialPlanner_student_person | null;
  appliedProducts: GetFinancialPlanner_student_appliedProducts[];
  workStudyAmount: GetFinancialPlanner_student_workStudyAmount;
  cashContributionAmount: GetFinancialPlanner_student_cashContributionAmount;
  collegeSavingsAmount: GetFinancialPlanner_student_collegeSavingsAmount;
  topChoice: GetFinancialPlanner_student_topChoice | null;
}

export interface GetFinancialPlanner {
  session: GetFinancialPlanner_session | null;
  student: GetFinancialPlanner_student;
}

export interface GetFinancialPlannerVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetLabs
// ====================================================

export interface GetLabs_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetLabs_colleges {
  __typename: "College";
  id: string;
  name: string;
  logo: GetLabs_colleges_logo | null;
}

export interface GetLabs {
  colleges: GetLabs_colleges[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetMetroAreaColleges
// ====================================================

export interface GetMetroAreaColleges_metroArea_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetMetroAreaColleges_metroArea_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetMetroAreaColleges_metroArea_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: GetMetroAreaColleges_metroArea_colleges_postalCode_city_state;
}

export interface GetMetroAreaColleges_metroArea_colleges_postalCode {
  __typename: "PostalCode";
  city: GetMetroAreaColleges_metroArea_colleges_postalCode_city;
}

export interface GetMetroAreaColleges_metroArea_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMetroAreaColleges_metroArea_colleges_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetMetroAreaColleges_metroArea_colleges_firstYearEarnings {
  __typename: "EarningsDataPoint";
  value: number;
}

export interface GetMetroAreaColleges_metroArea_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetMetroAreaColleges_metroArea_colleges_logo | null;
  url: string | null;
  urlSlugs: string[];
  postalCode: GetMetroAreaColleges_metroArea_colleges_postalCode;
  costOfAttendance: GetMetroAreaColleges_metroArea_colleges_costOfAttendance;
  edstimate: GetMetroAreaColleges_metroArea_colleges_edstimate;
  /**
   * from 0 to 1
   */
  firstYearEarnings: GetMetroAreaColleges_metroArea_colleges_firstYearEarnings[];
}

export interface GetMetroAreaColleges_metroArea {
  __typename: "MetroArea";
  id: string;
  name: string;
  colleges: GetMetroAreaColleges_metroArea_colleges[];
}

export interface GetMetroAreaColleges {
  metroArea: GetMetroAreaColleges_metroArea;
}

export interface GetMetroAreaCollegesVariables {
  studentId: string;
  metroAreaSlug: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetStateColleges
// ====================================================

export interface GetStateColleges_state_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetStateColleges_state_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetStateColleges_state_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: GetStateColleges_state_colleges_postalCode_city_state;
}

export interface GetStateColleges_state_colleges_postalCode {
  __typename: "PostalCode";
  city: GetStateColleges_state_colleges_postalCode_city;
}

export interface GetStateColleges_state_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetStateColleges_state_colleges_firstYearEarnings {
  __typename: "EarningsDataPoint";
  value: number;
}

export interface GetStateColleges_state_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  logo: GetStateColleges_state_colleges_logo | null;
  url: string | null;
  urlSlugs: string[];
  postalCode: GetStateColleges_state_colleges_postalCode;
  costOfAttendance: GetStateColleges_state_colleges_costOfAttendance;
  /**
   * from 0 to 1
   */
  firstYearEarnings: GetStateColleges_state_colleges_firstYearEarnings[];
}

export interface GetStateColleges_state {
  __typename: "State";
  id: string;
  name: string;
  colleges: GetStateColleges_state_colleges[];
}

export interface GetStateColleges {
  state: GetStateColleges_state;
}

export interface GetStateCollegesVariables {
  studentId: string;
  stateSlug: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetMetroAreas
// ====================================================

export interface GetMetroAreas_metroAreas {
  __typename: "MetroArea";
  id: string;
  abbreviation: string;
  name: string;
  slug: string | null;
}

export interface GetMetroAreas {
  metroAreas: GetMetroAreas_metroAreas[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetStates
// ====================================================

export interface GetStates_states {
  __typename: "State";
  id: string;
  abbreviation: string;
  name: string;
  slug: string | null;
}

export interface GetStates {
  states: GetStates_states[];
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetProfile
// ====================================================

export interface GetProfile_session_account_person_parent_household_efc {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetProfile_session_account_person_parent_household_income {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetProfile_session_account_person_parent_household {
  __typename: "Household";
  efc: GetProfile_session_account_person_parent_household_efc;
  income: GetProfile_session_account_person_parent_household_income;
}

export interface GetProfile_session_account_person_parent {
  __typename: "Parent";
  id: string;
  household: GetProfile_session_account_person_parent_household | null;
}

export interface GetProfile_session_account_person_counselor {
  __typename: "Counselor";
  id: string;
}

export interface GetProfile_session_account_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  type: PersonType | null;
  parent: GetProfile_session_account_person_parent | null;
  counselor: GetProfile_session_account_person_counselor | null;
}

export interface GetProfile_session_account {
  __typename: "Account";
  person: GetProfile_session_account_person | null;
}

export interface GetProfile_session {
  __typename: "Session";
  account: GetProfile_session_account;
}

export interface GetProfile_student_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
  type: PersonType | null;
  stage: Stage | null;
}

export interface GetProfile_student_highSchool_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetProfile_student_highSchool_postalCode_city {
  __typename: "City";
  name: string;
  state: GetProfile_student_highSchool_postalCode_city_state;
}

export interface GetProfile_student_highSchool_postalCode {
  __typename: "PostalCode";
  city: GetProfile_student_highSchool_postalCode_city;
  postalCode: string;
}

export interface GetProfile_student_highSchool {
  __typename: "HighSchool";
  id: string;
  name: string;
  postalCode: GetProfile_student_highSchool_postalCode;
}

export interface GetProfile_student_household_income {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetProfile_student_household_efc {
  __typename: "ComputedFloatValue" | "ComputedNullableFloatValue" | "UserNullableFloatValue" | "UserFloatValue" | "SystemNullableFloatValue" | "SystemFloatValue";
  value: number | null;
}

export interface GetProfile_student_household_postalCode {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
}

export interface GetProfile_student_household {
  __typename: "Household";
  income: GetProfile_student_household_income;
  efc: GetProfile_student_household_efc;
  postalCode: GetProfile_student_household_postalCode | null;
}

export interface GetProfile_student_major {
  __typename: "Major";
  id: string;
  name: string;
}

export interface GetProfile_student_collegeSavingsAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetProfile_student_workStudyAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetProfile_student_cashContributionAmount {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetProfile_student_highSchoolGraduationYear {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetProfile_student_gradePointAverage {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetProfile_student_weightedGradePointAverageMaximum {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetProfile_student_actScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetProfile_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetProfile_student_psatScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetProfile_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetProfile_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetProfile_student_appliedProducts_product;
}

export interface GetProfile_student {
  __typename: "Student";
  id: string;
  person: GetProfile_student_person | null;
  highSchool: GetProfile_student_highSchool | null;
  household: GetProfile_student_household | null;
  major: GetProfile_student_major | null;
  collegeSavingsAmount: GetProfile_student_collegeSavingsAmount;
  workStudyAmount: GetProfile_student_workStudyAmount;
  cashContributionAmount: GetProfile_student_cashContributionAmount;
  highSchoolGraduationYear: GetProfile_student_highSchoolGraduationYear;
  gradePointAverage: GetProfile_student_gradePointAverage;
  weightedGradePointAverageMaximum: GetProfile_student_weightedGradePointAverageMaximum;
  actScore: GetProfile_student_actScore;
  satScore: GetProfile_student_satScore;
  psatScore: GetProfile_student_psatScore;
  appliedProducts: GetProfile_student_appliedProducts[];
}

export interface GetProfile {
  session: GetProfile_session | null;
  student: GetProfile_student;
}

export interface GetProfileVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetWidgetStudent
// ====================================================

export interface GetWidgetStudent_session_account_person_student_gradePointAverage {
  __typename: "UserNullableStringValue";
  value: string | null;
}

export interface GetWidgetStudent_session_account_person_student_actScore {
  __typename: "UserNullableIntValue";
  value: number | null;
}

export interface GetWidgetStudent_session_account_person_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetWidgetStudent_session_account_person_student_household_postalCode {
  __typename: "PostalCode";
  id: string;
  postalCode: string;
}

export interface GetWidgetStudent_session_account_person_student_household {
  __typename: "Household";
  postalCode: GetWidgetStudent_session_account_person_student_household_postalCode | null;
}

export interface GetWidgetStudent_session_account_person_student_affordabilityBenchmark {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetWidgetStudent_session_account_person_student {
  __typename: "Student";
  id: string;
  gradePointAverage: GetWidgetStudent_session_account_person_student_gradePointAverage;
  actScore: GetWidgetStudent_session_account_person_student_actScore;
  satScore: GetWidgetStudent_session_account_person_student_satScore;
  household: GetWidgetStudent_session_account_person_student_household | null;
  affordabilityBenchmark: GetWidgetStudent_session_account_person_student_affordabilityBenchmark;
}

export interface GetWidgetStudent_session_account_person {
  __typename: "Person";
  id: string;
  student: GetWidgetStudent_session_account_person_student | null;
}

export interface GetWidgetStudent_session_account {
  __typename: "Account";
  id: string;
  person: GetWidgetStudent_session_account_person | null;
}

export interface GetWidgetStudent_session {
  __typename: "Session";
  account: GetWidgetStudent_session_account;
}

export interface GetWidgetStudent {
  session: GetWidgetStudent_session | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetWidgetCollege
// ====================================================

export interface GetWidgetCollege_college_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetWidgetCollege_college_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetWidgetCollege_college {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  costOfAttendance: GetWidgetCollege_college_costOfAttendance;
  edstimate: GetWidgetCollege_college_edstimate;
}

export interface GetWidgetCollege {
  college: GetWidgetCollege_college;
}

export interface GetWidgetCollegeVariables {
  collegeId: string;
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetRecommendations
// ====================================================

export interface GetRecommendations_session_account_person {
  __typename: "Person";
  type: PersonType | null;
}

export interface GetRecommendations_session_account {
  __typename: "Account";
  person: GetRecommendations_session_account_person | null;
}

export interface GetRecommendations_session {
  __typename: "Session";
  account: GetRecommendations_session_account;
}

export interface GetRecommendations_student_person {
  __typename: "Person";
  affinities: Affinity[] | null;
}

export interface GetRecommendations_student_affordabilityBenchmark {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetRecommendations_student_normalizedGPA {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_satScore {
  __typename: "ComputedIntValue" | "UserIntValue" | "SystemIntValue";
  value: number;
}

export interface GetRecommendations_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetRecommendations_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetRecommendations_student_appliedProducts_product;
}

export interface GetRecommendations_student_colleges {
  __typename: "College";
  id: string;
}

export interface GetRecommendations_student_hand_current {
  __typename: "College";
  id: string;
}

export interface GetRecommendations_student_hand {
  __typename: "Hand";
  current: GetRecommendations_student_hand_current[];
}

export interface GetRecommendations_student_recommendations_colleges_WithheldCollege {
  __typename: "WithheldCollege";
  id: string;
}

export interface GetRecommendations_student_recommendations_colleges_College_logo {
  __typename: "File";
  url: string;
}

export interface GetRecommendations_student_recommendations_colleges_College_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetRecommendations_student_recommendations_colleges_College_postalCode_city {
  __typename: "City";
  name: string;
  state: GetRecommendations_student_recommendations_colleges_College_postalCode_city_state;
}

export interface GetRecommendations_student_recommendations_colleges_College_postalCode {
  __typename: "PostalCode";
  city: GetRecommendations_student_recommendations_colleges_College_postalCode_city;
}

export interface GetRecommendations_student_recommendations_colleges_College_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_fitScore {
  __typename: "ComputedIntValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_affordabilityScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_valueScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_earningsScore {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_debtRemaining {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_admissibility {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetRecommendations_student_recommendations_colleges_College_admissionUnlikely {
  __typename: "ComputedBooleanValue";
  value: boolean;
}

export interface GetRecommendations_student_recommendations_colleges_College_averageGPA {
  __typename: "ComputedNullableFloatValue";
  value: number | null;
}

export interface GetRecommendations_student_recommendations_colleges_College_averageSATScore {
  __typename: "ComputedNullableIntValue";
  value: number | null;
}

export interface GetRecommendations_student_recommendations_colleges_College {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  recommendedReason: string | null;
  logo: GetRecommendations_student_recommendations_colleges_College_logo | null;
  postalCode: GetRecommendations_student_recommendations_colleges_College_postalCode;
  costOfAttendance: GetRecommendations_student_recommendations_colleges_College_costOfAttendance;
  edstimate: GetRecommendations_student_recommendations_colleges_College_edstimate;
  fitScore: GetRecommendations_student_recommendations_colleges_College_fitScore;
  affordabilityScore: GetRecommendations_student_recommendations_colleges_College_affordabilityScore;
  valueScore: GetRecommendations_student_recommendations_colleges_College_valueScore;
  earningsScore: GetRecommendations_student_recommendations_colleges_College_earningsScore;
  accumulatedEarnings: GetRecommendations_student_recommendations_colleges_College_accumulatedEarnings;
  debtRemaining: GetRecommendations_student_recommendations_colleges_College_debtRemaining[];
  /**
   * from 0 to 1
   */
  medianEarnings: GetRecommendations_student_recommendations_colleges_College_medianEarnings[];
  admissibility: GetRecommendations_student_recommendations_colleges_College_admissibility;
  admissionUnlikely: GetRecommendations_student_recommendations_colleges_College_admissionUnlikely;
  averageGPA: GetRecommendations_student_recommendations_colleges_College_averageGPA;
  averageSATScore: GetRecommendations_student_recommendations_colleges_College_averageSATScore;
}

export type GetRecommendations_student_recommendations_colleges = GetRecommendations_student_recommendations_colleges_WithheldCollege | GetRecommendations_student_recommendations_colleges_College;

export interface GetRecommendations_student_recommendations {
  __typename: "Recommendation";
  id: string;
  title: string;
  colleges: GetRecommendations_student_recommendations_colleges[];
}

export interface GetRecommendations_student {
  __typename: "Student";
  id: string;
  person: GetRecommendations_student_person | null;
  affordabilityBenchmark: GetRecommendations_student_affordabilityBenchmark;
  normalizedGPA: GetRecommendations_student_normalizedGPA;
  satScore: GetRecommendations_student_satScore;
  appliedProducts: GetRecommendations_student_appliedProducts[];
  colleges: GetRecommendations_student_colleges[];
  hand: GetRecommendations_student_hand;
  recommendations: GetRecommendations_student_recommendations[];
}

export interface GetRecommendations {
  session: GetRecommendations_session | null;
  student: GetRecommendations_student;
}

export interface GetRecommendationsVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetSEOCollegeComparison
// ====================================================

export interface GetSEOCollegeComparison_comparison_colleges_logo {
  __typename: "File";
  url: string;
}

export interface GetSEOCollegeComparison_comparison_colleges_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface GetSEOCollegeComparison_comparison_colleges_postalCode_city {
  __typename: "City";
  name: string;
  state: GetSEOCollegeComparison_comparison_colleges_postalCode_city_state;
}

export interface GetSEOCollegeComparison_comparison_colleges_postalCode {
  __typename: "PostalCode";
  city: GetSEOCollegeComparison_comparison_colleges_postalCode_city;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from = GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserNullableBooleanValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_UserBooleanValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemNullableBooleanValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_SystemBooleanValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableFloatValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedIntValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedBooleanValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedStringValue | GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from_ComputedNullableBooleanValue;

export interface GetSEOCollegeComparison_comparison_colleges_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
  from: GetSEOCollegeComparison_comparison_colleges_costOfAttendance_from[];
}

export interface GetSEOCollegeComparison_comparison_colleges_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface GetSEOCollegeComparison_comparison_colleges_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetSEOCollegeComparison_comparison_colleges {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  type: CollegeType;
  url: string | null;
  logo: GetSEOCollegeComparison_comparison_colleges_logo | null;
  postalCode: GetSEOCollegeComparison_comparison_colleges_postalCode;
  costOfAttendance: GetSEOCollegeComparison_comparison_colleges_costOfAttendance;
  repaymentRate: number;
  /**
   * from 0 to 1
   */
  averageMeritScholarship: number | null;
  averagePrice: number | null;
  /**
   * from 0 to 1
   */
  medianEarnings: GetSEOCollegeComparison_comparison_colleges_medianEarnings[];
  accumulatedEarnings: GetSEOCollegeComparison_comparison_colleges_accumulatedEarnings;
}

export interface GetSEOCollegeComparison_comparison {
  __typename: "Comparison";
  title: string;
  colleges: GetSEOCollegeComparison_comparison_colleges[];
}

export interface GetSEOCollegeComparison {
  comparison: GetSEOCollegeComparison_comparison;
}

export interface GetSEOCollegeComparisonVariables {
  studentId: string;
  comparisonSlug: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetSabrinaBotMessages
// ====================================================

export interface GetSabrinaBotMessages_student_sabrinaBotMessages_SabrinaBotTextMessage {
  __typename: "SabrinaBotTextMessage";
  id: string;
  createdAt: any;
  text: string;
  actions: string[] | null;
  selectedAction: string | null;
}

export interface GetSabrinaBotMessages_student_sabrinaBotMessages_SabrinaBotCTAMessage {
  __typename: "SabrinaBotCTAMessage";
  id: string;
  createdAt: any;
  text: string;
  actions: string[] | null;
  selectedAction: string | null;
  callToActionText: string;
  callToActionUrl: string | null;
}

export type GetSabrinaBotMessages_student_sabrinaBotMessages = GetSabrinaBotMessages_student_sabrinaBotMessages_SabrinaBotTextMessage | GetSabrinaBotMessages_student_sabrinaBotMessages_SabrinaBotCTAMessage;

export interface GetSabrinaBotMessages_student {
  __typename: "Student";
  id: string;
  sabrinaBotMessages: GetSabrinaBotMessages_student_sabrinaBotMessages[] | null;
}

export interface GetSabrinaBotMessages {
  student: GetSabrinaBotMessages_student;
}

export interface GetSabrinaBotMessagesVariables {
  studentId: string;
  page: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetAppeals
// ====================================================

export interface GetAppeals_session_account {
  __typename: "Account";
  isSuperUser: boolean;
}

export interface GetAppeals_session {
  __typename: "Session";
  account: GetAppeals_session_account;
}

export interface GetAppeals_student_appliedProducts_product {
  __typename: "Product";
  name: string;
}

export interface GetAppeals_student_appliedProducts {
  __typename: "AppliedStudentProduct";
  id: string;
  expiresAt: any | null;
  renewsAt: any | null;
  product: GetAppeals_student_appliedProducts_product;
}

export interface GetAppeals_student_colleges_edstimate {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface GetAppeals_student_colleges_financialAidAppealLetter {
  __typename: "File";
  id: string;
}

export interface GetAppeals_student_colleges {
  __typename: "College";
  id: string;
  name: string;
  status: CollegeStatus | null;
  edstimate: GetAppeals_student_colleges_edstimate;
  financialAidAward: number | null;
  financialAidAppealAward: number | null;
  financialAidAppealLetter: GetAppeals_student_colleges_financialAidAppealLetter | null;
}

export interface GetAppeals_student {
  __typename: "Student";
  id: string;
  appliedProducts: GetAppeals_student_appliedProducts[];
  colleges: GetAppeals_student_colleges[];
}

export interface GetAppeals {
  session: GetAppeals_session | null;
  student: GetAppeals_student;
}

export interface GetAppealsVariables {
  studentId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: GetFileDownloadUrl
// ====================================================

export interface GetFileDownloadUrl_file {
  __typename: "File";
  id: string;
  downloadUrl: string;
}

export interface GetFileDownloadUrl {
  file: GetFileDownloadUrl_file;
}

export interface GetFileDownloadUrlVariables {
  studentId: string;
  fileId: string;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: UserValueFragment
// ====================================================

export interface UserValueFragment_UserFloatValue {
  __typename: "UserFloatValue";
  floatValue: number;
}

export interface UserValueFragment_UserIntValue {
  __typename: "UserIntValue";
  intValue: number;
}

export interface UserValueFragment_UserStringValue {
  __typename: "UserStringValue";
  stringValue: string;
}

export interface UserValueFragment_UserBooleanValue {
  __typename: "UserBooleanValue";
  booleanValue: boolean;
}

export interface UserValueFragment_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  nullableFloatValue: number | null;
}

export interface UserValueFragment_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  nullableIntValue: number | null;
}

export interface UserValueFragment_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  nullableStringValue: string | null;
}

export interface UserValueFragment_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  nullableBooleanValue: boolean | null;
}

export type UserValueFragment = UserValueFragment_UserFloatValue | UserValueFragment_UserIntValue | UserValueFragment_UserStringValue | UserValueFragment_UserBooleanValue | UserValueFragment_UserNullableFloatValue | UserValueFragment_UserNullableIntValue | UserValueFragment_UserNullableStringValue | UserValueFragment_UserNullableBooleanValue;

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: SystemValueFragment
// ====================================================

export interface SystemValueFragment_SystemFloatValue {
  __typename: "SystemFloatValue";
  floatValue: number;
}

export interface SystemValueFragment_SystemIntValue {
  __typename: "SystemIntValue";
  intValue: number;
}

export interface SystemValueFragment_SystemStringValue {
  __typename: "SystemStringValue";
  stringValue: string;
}

export interface SystemValueFragment_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  booleanValue: boolean;
}

export interface SystemValueFragment_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  nullableFloatValue: number | null;
}

export interface SystemValueFragment_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  nullableIntValue: number | null;
}

export interface SystemValueFragment_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  nullableStringValue: string | null;
}

export interface SystemValueFragment_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  nullableBooleanValue: boolean | null;
}

export type SystemValueFragment = SystemValueFragment_SystemFloatValue | SystemValueFragment_SystemIntValue | SystemValueFragment_SystemStringValue | SystemValueFragment_SystemBooleanValue | SystemValueFragment_SystemNullableFloatValue | SystemValueFragment_SystemNullableIntValue | SystemValueFragment_SystemNullableStringValue | SystemValueFragment_SystemNullableBooleanValue;

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: ComputedValueFragment
// ====================================================

export interface ComputedValueFragment_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface ComputedValueFragment_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface ComputedValueFragment_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface ComputedValueFragment_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface ComputedValueFragment_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface ComputedValueFragment_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface ComputedValueFragment_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface ComputedValueFragment_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type ComputedValueFragment = ComputedValueFragment_ComputedFloatValue | ComputedValueFragment_ComputedIntValue | ComputedValueFragment_ComputedStringValue | ComputedValueFragment_ComputedBooleanValue | ComputedValueFragment_ComputedNullableFloatValue | ComputedValueFragment_ComputedNullableIntValue | ComputedValueFragment_ComputedNullableStringValue | ComputedValueFragment_ComputedNullableBooleanValue;

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: ValueFragment
// ====================================================

export interface ValueFragment_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface ValueFragment_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface ValueFragment_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface ValueFragment_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface ValueFragment_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface ValueFragment_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface ValueFragment_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface ValueFragment_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface ValueFragment_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface ValueFragment_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface ValueFragment_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface ValueFragment_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface ValueFragment_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface ValueFragment_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface ValueFragment_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface ValueFragment_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface ValueFragment_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface ValueFragment_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface ValueFragment_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface ValueFragment_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface ValueFragment_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface ValueFragment_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface ValueFragment_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface ValueFragment_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type ValueFragment = ValueFragment_UserNullableIntValue | ValueFragment_UserNullableStringValue | ValueFragment_UserIntValue | ValueFragment_UserNullableFloatValue | ValueFragment_UserFloatValue | ValueFragment_UserStringValue | ValueFragment_UserNullableBooleanValue | ValueFragment_UserBooleanValue | ValueFragment_SystemNullableIntValue | ValueFragment_SystemIntValue | ValueFragment_SystemNullableFloatValue | ValueFragment_SystemFloatValue | ValueFragment_SystemNullableStringValue | ValueFragment_SystemStringValue | ValueFragment_SystemNullableBooleanValue | ValueFragment_SystemBooleanValue | ValueFragment_ComputedFloatValue | ValueFragment_ComputedNullableIntValue | ValueFragment_ComputedNullableFloatValue | ValueFragment_ComputedIntValue | ValueFragment_ComputedBooleanValue | ValueFragment_ComputedNullableStringValue | ValueFragment_ComputedStringValue | ValueFragment_ComputedNullableBooleanValue;

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: ComputedFloatValueFragment
// ====================================================

export interface ComputedFloatValueFragment_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface ComputedFloatValueFragment_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface ComputedFloatValueFragment_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface ComputedFloatValueFragment_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface ComputedFloatValueFragment_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface ComputedFloatValueFragment_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface ComputedFloatValueFragment_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface ComputedFloatValueFragment_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface ComputedFloatValueFragment_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface ComputedFloatValueFragment_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface ComputedFloatValueFragment_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface ComputedFloatValueFragment_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface ComputedFloatValueFragment_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface ComputedFloatValueFragment_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface ComputedFloatValueFragment_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface ComputedFloatValueFragment_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface ComputedFloatValueFragment_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface ComputedFloatValueFragment_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface ComputedFloatValueFragment_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface ComputedFloatValueFragment_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface ComputedFloatValueFragment_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface ComputedFloatValueFragment_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface ComputedFloatValueFragment_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface ComputedFloatValueFragment_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type ComputedFloatValueFragment_from = ComputedFloatValueFragment_from_UserNullableIntValue | ComputedFloatValueFragment_from_UserNullableStringValue | ComputedFloatValueFragment_from_UserIntValue | ComputedFloatValueFragment_from_UserNullableFloatValue | ComputedFloatValueFragment_from_UserFloatValue | ComputedFloatValueFragment_from_UserStringValue | ComputedFloatValueFragment_from_UserNullableBooleanValue | ComputedFloatValueFragment_from_UserBooleanValue | ComputedFloatValueFragment_from_SystemNullableIntValue | ComputedFloatValueFragment_from_SystemIntValue | ComputedFloatValueFragment_from_SystemNullableFloatValue | ComputedFloatValueFragment_from_SystemFloatValue | ComputedFloatValueFragment_from_SystemNullableStringValue | ComputedFloatValueFragment_from_SystemStringValue | ComputedFloatValueFragment_from_SystemNullableBooleanValue | ComputedFloatValueFragment_from_SystemBooleanValue | ComputedFloatValueFragment_from_ComputedFloatValue | ComputedFloatValueFragment_from_ComputedNullableIntValue | ComputedFloatValueFragment_from_ComputedNullableFloatValue | ComputedFloatValueFragment_from_ComputedIntValue | ComputedFloatValueFragment_from_ComputedBooleanValue | ComputedFloatValueFragment_from_ComputedNullableStringValue | ComputedFloatValueFragment_from_ComputedStringValue | ComputedFloatValueFragment_from_ComputedNullableBooleanValue;

export interface ComputedFloatValueFragment {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  from: ComputedFloatValueFragment_from[];
  value: number;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: StudentFragment
// ====================================================

export interface StudentFragment_person {
  __typename: "Person";
  firstName: string | null;
  lastName: string | null;
}

export interface StudentFragment {
  __typename: "Student";
  id: string;
  person: StudentFragment_person | null;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL fragment: SEOCollege
// ====================================================

export interface SEOCollege_logo {
  __typename: "File";
  url: string;
}

export interface SEOCollege_postalCode_city_state {
  __typename: "State";
  name: string;
  abbreviation: string;
}

export interface SEOCollege_postalCode_city {
  __typename: "City";
  name: string;
  state: SEOCollege_postalCode_city_state;
}

export interface SEOCollege_postalCode {
  __typename: "PostalCode";
  city: SEOCollege_postalCode_city;
}

export interface SEOCollege_costOfAttendance_from_UserNullableIntValue {
  __typename: "UserNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_UserNullableStringValue {
  __typename: "UserNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface SEOCollege_costOfAttendance_from_UserIntValue {
  __typename: "UserIntValue";
  name: string;
  intValue: number;
}

export interface SEOCollege_costOfAttendance_from_UserNullableFloatValue {
  __typename: "UserNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_UserFloatValue {
  __typename: "UserFloatValue";
  name: string;
  floatValue: number;
}

export interface SEOCollege_costOfAttendance_from_UserStringValue {
  __typename: "UserStringValue";
  name: string;
  stringValue: string;
}

export interface SEOCollege_costOfAttendance_from_UserNullableBooleanValue {
  __typename: "UserNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface SEOCollege_costOfAttendance_from_UserBooleanValue {
  __typename: "UserBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface SEOCollege_costOfAttendance_from_SystemNullableIntValue {
  __typename: "SystemNullableIntValue";
  name: string;
  nullableIntValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_SystemIntValue {
  __typename: "SystemIntValue";
  name: string;
  intValue: number;
}

export interface SEOCollege_costOfAttendance_from_SystemNullableFloatValue {
  __typename: "SystemNullableFloatValue";
  name: string;
  nullableFloatValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_SystemFloatValue {
  __typename: "SystemFloatValue";
  name: string;
  floatValue: number;
}

export interface SEOCollege_costOfAttendance_from_SystemNullableStringValue {
  __typename: "SystemNullableStringValue";
  name: string;
  nullableStringValue: string | null;
}

export interface SEOCollege_costOfAttendance_from_SystemStringValue {
  __typename: "SystemStringValue";
  name: string;
  stringValue: string;
}

export interface SEOCollege_costOfAttendance_from_SystemNullableBooleanValue {
  __typename: "SystemNullableBooleanValue";
  name: string;
  nullableBooleanValue: boolean | null;
}

export interface SEOCollege_costOfAttendance_from_SystemBooleanValue {
  __typename: "SystemBooleanValue";
  name: string;
  booleanValue: boolean;
}

export interface SEOCollege_costOfAttendance_from_ComputedFloatValue {
  __typename: "ComputedFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  floatValue: number;
}

export interface SEOCollege_costOfAttendance_from_ComputedNullableIntValue {
  __typename: "ComputedNullableIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableIntValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_ComputedNullableFloatValue {
  __typename: "ComputedNullableFloatValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableFloatValue: number | null;
}

export interface SEOCollege_costOfAttendance_from_ComputedIntValue {
  __typename: "ComputedIntValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  intValue: number;
}

export interface SEOCollege_costOfAttendance_from_ComputedBooleanValue {
  __typename: "ComputedBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  booleanValue: boolean;
}

export interface SEOCollege_costOfAttendance_from_ComputedNullableStringValue {
  __typename: "ComputedNullableStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableStringValue: string | null;
}

export interface SEOCollege_costOfAttendance_from_ComputedStringValue {
  __typename: "ComputedStringValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  stringValue: string;
}

export interface SEOCollege_costOfAttendance_from_ComputedNullableBooleanValue {
  __typename: "ComputedNullableBooleanValue";
  name: string;
  computedAt: any;
  staleAt: any | null;
  nullableBooleanValue: boolean | null;
}

export type SEOCollege_costOfAttendance_from = SEOCollege_costOfAttendance_from_UserNullableIntValue | SEOCollege_costOfAttendance_from_UserNullableStringValue | SEOCollege_costOfAttendance_from_UserIntValue | SEOCollege_costOfAttendance_from_UserNullableFloatValue | SEOCollege_costOfAttendance_from_UserFloatValue | SEOCollege_costOfAttendance_from_UserStringValue | SEOCollege_costOfAttendance_from_UserNullableBooleanValue | SEOCollege_costOfAttendance_from_UserBooleanValue | SEOCollege_costOfAttendance_from_SystemNullableIntValue | SEOCollege_costOfAttendance_from_SystemIntValue | SEOCollege_costOfAttendance_from_SystemNullableFloatValue | SEOCollege_costOfAttendance_from_SystemFloatValue | SEOCollege_costOfAttendance_from_SystemNullableStringValue | SEOCollege_costOfAttendance_from_SystemStringValue | SEOCollege_costOfAttendance_from_SystemNullableBooleanValue | SEOCollege_costOfAttendance_from_SystemBooleanValue | SEOCollege_costOfAttendance_from_ComputedFloatValue | SEOCollege_costOfAttendance_from_ComputedNullableIntValue | SEOCollege_costOfAttendance_from_ComputedNullableFloatValue | SEOCollege_costOfAttendance_from_ComputedIntValue | SEOCollege_costOfAttendance_from_ComputedBooleanValue | SEOCollege_costOfAttendance_from_ComputedNullableStringValue | SEOCollege_costOfAttendance_from_ComputedStringValue | SEOCollege_costOfAttendance_from_ComputedNullableBooleanValue;

export interface SEOCollege_costOfAttendance {
  __typename: "ComputedFloatValue";
  value: number;
  from: SEOCollege_costOfAttendance_from[];
}

export interface SEOCollege_medianEarnings {
  __typename: "EarningsDataPoint";
  year: number;
  value: number;
}

export interface SEOCollege_accumulatedEarnings {
  __typename: "ComputedFloatValue";
  value: number;
}

export interface SEOCollege {
  __typename: "College";
  id: string;
  name: string;
  abbreviation: string;
  type: CollegeType;
  url: string | null;
  logo: SEOCollege_logo | null;
  postalCode: SEOCollege_postalCode;
  costOfAttendance: SEOCollege_costOfAttendance;
  repaymentRate: number;
  /**
   * from 0 to 1
   */
  averageMeritScholarship: number | null;
  averagePrice: number | null;
  /**
   * from 0 to 1
   */
  medianEarnings: SEOCollege_medianEarnings[];
  accumulatedEarnings: SEOCollege_accumulatedEarnings;
}

/* tslint:disable */
// This file was automatically generated and should not be edited.

//==============================================================
// START Enums and Input Objects
//==============================================================

export enum Affinity {
  Affordability = "Affordability",
  Earnings = "Earnings",
  Value = "Value",
}

export enum CollegeStatus {
  Accepted = "Accepted",
  Appealing = "Appealing",
  Applied = "Applied",
  Attending = "Attending",
  Considering = "Considering",
  NotAppealing = "NotAppealing",
  NotAttending = "NotAttending",
}

export enum CollegeType {
  PRIVATE = "PRIVATE",
  PUBLIC = "PUBLIC",
}

export enum EStripePaymentStatus {
  PaymentError = "PaymentError",
  Success = "Success",
}

export enum InvitationStatus {
  AccountWithEmailAlreadyExists = "AccountWithEmailAlreadyExists",
  InvalidEmailAddress = "InvalidEmailAddress",
  Invited = "Invited",
}

export enum InviterPermission {
  Edit = "Edit",
  NoAccess = "NoAccess",
  View = "View",
}

export enum LoginError {
  InvalidCredentials = "InvalidCredentials",
  Other = "Other",
}

export enum PersonType {
  Other = "Other",
  Parent = "Parent",
  Student = "Student",
}

export enum SignupError {
  InvalidEmailAddress = "InvalidEmailAddress",
  PasswordNotComplexEnough = "PasswordNotComplexEnough",
}

export enum Stage {
  Applying = "Applying",
  Looking = "Looking",
  Negotiating = "Negotiating",
  PlanningForPayment = "PlanningForPayment",
}

export interface ProfileUpdateInput {
  accountType?: PersonType | null;
  emailAddress?: string | null;
  password?: string | null;
  firstName?: string | null;
  lastName?: string | null;
  gradePointAverage?: UserNullableStringValueInput | null;
  actScore?: UserNullableIntValueInput | null;
  satScore?: UserNullableIntValueInput | null;
  psatScore?: UserNullableIntValueInput | null;
  efc?: UserNullableFloatValueInput | null;
  householdIncome?: UserNullableFloatValueInput | null;
  postalCodeId?: string | null;
  highSchoolId?: string | null;
  highSchoolGraduationYear?: UserNullableIntValueInput | null;
  collegeSavingsPlanAmount?: UserNullableFloatValueInput | null;
  primaryGoal?: string | null;
  majorId?: string | null;
  topChoiceCollegeId?: string | null;
  cashContributionAmount?: UserNullableFloatValueInput | null;
  workStudyAmount?: UserNullableFloatValueInput | null;
  affinities?: Affinity[] | null;
  weightedGradePointAverageMaximum?: UserNullableStringValueInput | null;
  stage?: Stage | null;
}

export interface UpdateFinancialAidAppealInput {
  appealAidAward?: UserNullableIntValueInput | null;
  appealLetter?: UploadFileInput | null;
}

export interface UpdateFinancialAidInput {
  aidAward?: UserNullableIntValueInput | null;
  aidLetter?: UploadFileInput | null;
}

export interface UploadFileInput {
  name?: string | null;
  dataUrl: string;
}

export interface UserNullableFloatValueInput {
  value?: number | null;
}

export interface UserNullableIntValueInput {
  value?: number | null;
}

export interface UserNullableStringValueInput {
  value?: string | null;
}

//==============================================================
// END Enums and Input Objects
//==============================================================
